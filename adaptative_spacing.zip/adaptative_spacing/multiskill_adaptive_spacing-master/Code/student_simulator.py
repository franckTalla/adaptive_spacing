import numpy as np
from collections import defaultdict
from strategies import greedy_skill_selection, greedy_multiskill_selection
from utils import gen_outcome, intersection, custom_argmax, custom_argmin,\
     gen_cplx_outcome, OurQueue

class single_student:
    """
    Class for simulating a single student, based on the DAS3H model.

    Input:
        * review_strat: name of the skill selection strategy;
        * param_review: parameter chosen for the skill selection strategy;
        * B: number of blocks (skills) in the learning simulation;
        * list_of_ri: list of retention intervals. Each ri in list_of_ri indicates that the student's proficiency will
        be assessed at timestamp B-1+ri;
        * stud_alpha: alpha (ability) parameter of the student;
        * skill_betas: list of beta easiness parameters, in the same order as the introduction of each skill;
        * list_of_win_params: list of arrays. Each array contains the odd (wins) thetas for each skill b. Inside
        each thetas array, the thetas are ordered from the shortest to the largest time window.
        * list_of_att_params: list of arrays. Each array contains the even (attempts) thetas for each skill b. Inside
        each thetas array, the thetas are ordered from the shortest to the largest time window.
        * q_mat: q-matrix, same as output from generation.generate_q_matrix;
        * inv_q_mat: inverse q-matrix, same as output from generation.generate_q_matrix;
        * item_deltas: array of item deltas, ordered as in the q-matrix;
        * items_per_skill: number (int) of items to generate per skill (cf. generation.generate_q_matrix);
        * est_deltas: estimated deltas (for the estimated version of the skill strategies);
        * est_betas: estimated betas (for the estimated version of the skill strategies);
        * est_win_params, est_att_params: estimated win and att params (for the estimated version of the skill strategies);
        * reviews_per_step: int, number of reviews performed by a student at each week;
        * item_strat: str, item strategy name, either 'random' or 'max_skills'
    """
    def __init__(self, review_strat, param_review, B, list_of_ri, stud_alpha, skill_betas, list_of_win_params,
                 list_of_att_params, q_mat, inv_q_mat, item_deltas, items_per_skill,
                 est_deltas, est_betas, est_win_params, est_att_params, reviews_per_step=3, item_strat="random"):
        self.review_strat = review_strat
        self.param_review = param_review
        self.B = B
        self.list_of_ri = list_of_ri
        self.stud_alpha = stud_alpha
        self.skill_betas = skill_betas
        self.list_of_win_params = list_of_win_params # Attention, must be the same as the ones chosen by the algo!
        self.list_of_att_params = list_of_att_params # Attention, must be the same as the ones chosen by the algo!
        self.qmat = q_mat
        self.inv_q_mat = inv_q_mat
        self.item_deltas = item_deltas
        self.items_per_skill = items_per_skill
        self.est_deltas = est_deltas
        self.est_betas = est_betas
        self.est_win_params = est_win_params
        self.est_att_params = est_att_params
        self.reviews_per_step = reviews_per_step
        self.item_strat = item_strat
        self.q = defaultdict(lambda: OurQueue())
        
        """
        
            * acceptable  : is a dictionary that you have to initialise yourself according to a specific evidenceb schedule
            
            acceptable[i] are all the different exercices that can be done at the week i.
            in other to select an acivity for the revision we must choose one that use only objectives that have allredy be done
            
            it is use for multi-selection strategy : "theta_thres_multiskill","theta_thres_multiskill_est", "greedy_multiskill","greedy_multiskill_est"
            
            use:
                when the different skill that must be revised are chosen (in selected_skil, a list of different objective that the student will revise), 
                the set of acceptable activities is the intersection of inv_qmat[selected_skill[0]] and acceptable[week]
                and we make the intersection with all the other list of activity that requires the rest of the selected_skill
            
        """
        
        self.acceptable = {}       
        self.acceptable[0] = [i for i in range(7)]
        self.acceptable[1] = [i for i in range(14)]
        self.acceptable[2] = [i for i in range(24)]
        self.acceptable[3] = [i for i in range(34)]
        self.acceptable[4] = [i for i in range(44)]
        self.acceptable[5] = [i for i in range(54)]
        self.acceptable[6] = [i for i in range(64)]
        self.acceptable[7] = [i for i in range(74)]
        self.acceptable[8] = [i for i in range(84)]
    
    def choose_skill(self, week):
        """
        Choose skill to review on a given week.

        Input:
            * week: int, current week number. Starts in the beginning at 0.
        """
        # cette fontction retourne selected block qui est la semaine choisie ou l'ensemble des semaines choisies (s'il s'agit d'une méthode de selection multiple comme theta_thres_multiskill, ou greedy_multiskill ) pour les révisions à la semaine week
        # l'ensemble possible de sélection est [0, week -1]
        if self.review_strat == "random_review":
            selected_block = np.random.choice(week,1)[0]
        elif self.review_strat == "mu_back": # mu must be > 0
            selected_block = max(week-self.param_review,0)
        elif self.review_strat.startswith("theta_thres"):
            # Output for uniskill strats = skill id; for multiskill strats = item id
            # liste des probabilités de rappel des différentes notions abordées de la semaine 0 à la semaine week
            # a titre de rappel on pourra ainsi déterminer la semaine dont la probabilité de rappel est la plus proche du parametre theta
            probas_recall = []
            for j in range(week):
                win_counters = self.q[(j,"wins")].get_counters(week*3600*24*7)
                attempt_counters = self.q[(j,"attempts")].get_counters(week*3600*24*7)
                if self.review_strat in ["theta_thres","theta_thres_multiskill"]:
                    probas_recall.append(gen_outcome(self.stud_alpha, self.item_deltas.mean(), self.skill_betas[j],
                                                     win_counters, attempt_counters, self.list_of_win_params[j],
                                                     self.list_of_att_params[j]))
                elif self.review_strat in ["theta_thres_est","theta_thres_multiskill_est"]:
                    # le 0 mis pour les méthodes d'estimation est un choix du chercheur qui sont en parti justifiés par la répartition des alpha choisi pour l'expérience
                    # il a choisi une loi normale centrée en 0 et de variance 1 (voir page 64 du document/ page 84 sur le lecteur de PDF)
                    # les paramètres de l'étudiant n'étant pas connu dans le cadre de cette méthode il choisit la valeur moyenne comme niveau de l'élève
                    probas_recall.append(gen_outcome(0, self.est_deltas.mean(), self.est_betas[j],
                                                     win_counters, attempt_counters, self.est_win_params[j],
                                                     self.est_att_params[j]))
            if self.review_strat in ["theta_thres","theta_thres_est"]:
                # pour cette méthode la semaine sélectionnée est celle dont la probabilité de succès est le plus proche du paramètre théta
                selected_block = np.argmin(np.absolute(np.array(probas_recall)-self.param_review))
            elif self.review_strat in ["theta_thres_multiskill","theta_thres_multiskill_est"]:
                selected_skills = []
                selected_skills.append(np.argmin(np.absolute(np.array(probas_recall)-self.param_review)))
                # le principe de ces startégies de selection est de choisie au départ un premier objectif, celui avec la probabilité de succès la plus proche de theta
                # puis on trie les objectifs par odre croissant de distance de leur probailité de succès au paramètre theta (stockés dans increasing_order)
                # on parcours l'ensemble des objectifs triés et stockés dans increasing_order pour identifier l'ensemble des activités qui font intervenir un maximum d'objectifs
                
                increasing_order = np.argsort(np.absolute(np.array(probas_recall)-self.param_review))
                
                
                #acceptable_items = [item_id for item_id in self.inv_q_mat[selected_skills[0]] if item_id < week*self.items_per_skill]
                
                
 
                # ici on définir une liste d'activité acceptable qui font travaillé le premier objectif selectionné (stockée dans selected_skills[0]) et qui ne font intervenir que des objectifs qui ont déjà été vu jusque là, de la semaine 0 à la semaine week 
                # voir l'explication ci dessus du principe de la variable acceptable
                acceptable_items = [item_id for item_id in self.inv_q_mat[selected_skills[0]] if (item_id in self.acceptable[week])]
                
                 
                # on parcours increasing_order en faisant à chaque fois une intersection entre l'ensemble des activités acceptables déjà trouvées et l'ensemble des activités de la qui fobnt intervenir l'objectif correspondant à increasing_order[k]
                # si l'intersection est vide on passe à l'objectif suivant dans l'ordre de proximité à theta
                for k in range(1,len(probas_recall)):
                    intersec_items = intersection(acceptable_items,self.inv_q_mat[increasing_order[k]])
                    if len(intersec_items) == 0:
                        continue
                    else:
                        acceptable_items = intersec_items.copy()
                
                # acceptable_items est nécessairement non vide car si à une étape on obtient une intersection vide on ne considère pas la semaine en question
                selected_block = np.random.choice(acceptable_items) # We call it "block" but in fact it's the item index
        elif self.review_strat in ["greedy","greedy_est"]:
            # Output for uniskill strats = skill id
            if self.review_strat == "greedy":
                selected_block = greedy_skill_selection(week, self.B, self.list_of_ri, self.stud_alpha, self.item_deltas.mean(),
                                                        self.skill_betas, self.list_of_win_params, self.list_of_att_params, self.q)
            elif self.review_strat == "greedy_est":
                selected_block = greedy_skill_selection(week, self.B, self.list_of_ri, 0, self.est_deltas.mean(), self.est_betas,
                                                        self.est_win_params, self.est_att_params, self.q)
        elif self.review_strat in ["greedy_multiskill","greedy_multiskill_est"]:
            # Output for multiskill strats = item id
            if self.review_strat == "greedy_multiskill":
                selected_block = greedy_multiskill_selection(week, self.B, self.list_of_ri, self.stud_alpha, self.item_deltas.mean(),
                                                             self.skill_betas, self.list_of_win_params, self.list_of_att_params, self.q,
                                                             self.qmat, self.inv_q_mat, self.items_per_skill)
            elif self.review_strat == "greedy_multiskill_est":
                selected_block = greedy_multiskill_selection(week, self.B, self.list_of_ri, 0, self.est_deltas.mean(), self.est_betas,
                                                             self.est_win_params, self.est_att_params, self.q, self.qmat,
                                                             self.inv_q_mat, self.items_per_skill)
        return selected_block
    
    def choose_item(self, selected_block, week):
        # cette methode retourne l'activité selectionnée selected_item
        #acceptable_items = [item_id for item_id in self.inv_q_mat[selected_block] if item_id < week*self.items_per_skill]
        acceptable_items = [item_id for item_id in self.inv_q_mat[selected_block] if (item_id in self.acceptable[selected_block])]
        if self.item_strat == "random":
            selected_item = np.random.choice(acceptable_items)
        elif self.item_strat == "max_skills":
            temp_nb_skills = []
            for item_id in acceptable_items:
                temp_nb_skills.append(len(self.qmat[item_id]))
            selected_item = acceptable_items[custom_argmax(np.array(temp_nb_skills))]
        return selected_item
    
    def learn_and_review(self):
        # voir algorithme 1 page 61 du document (page 81 du lecteur de PDF)
        temp_recall_probs = [] # stores lists of correctness probas for each skill, at each learning week
        sum_attempts = [] # stores temp_sum_attempts for each week
        temp_sum_attempts = 0 # counts total nb of skills reviewed up to any timestamp
        temp_results = [] # stores ACP at each learning week
        attempts_per_skill = [] # stores lists of skill review attempts for any week
        for week in range(self.B):
            # Learn weekly material
            self.q[(week,"attempts")].push(week*7*24*3600) # When students learn, we add +1 attempt to their history
            temp_sum_attempts += 1
            # Test : are there attempts that have been pushed for a timestamp > current timestamp (cf. OurQueue doc)?
            current_queue_att = self.q[(week,"attempts")].queue
            current_queue_win = self.q[(week,"wins")].queue
            if len(current_queue_att) > 0:
                if np.max(current_queue_att) > week*7*24*3600:
                    print("Error: the queue contains posterior attempts. Please refer to utils.OurQueue doc.")
            if len(current_queue_win) > 0:
                if np.max(current_queue_win) > week*7*24*3600:
                    print("Error: the queue contains posterior wins. Please refer to utils.OurQueue doc.")
            # A student can only review from 2nd week (= week 1) and can only review blocks until past week
            list_att_per_skill = np.zeros(self.B) # stores skill review attempts in a given week
            if (self.review_strat != "no_review") & (week > 0):
                for j in range(self.reviews_per_step):
                    selected_block = self.choose_skill(week)
                    # Choose item which involves selected skill
                    if self.review_strat in ["greedy_multiskill","greedy_multiskill_est",
                                             "theta_thres_multiskill","theta_thres_multiskill_est"]:
                        selected_item_id = selected_block
                        # Store attempts on each selected skill
                        for b in self.qmat[selected_item_id]:
                            list_att_per_skill[b] += 1
                    else:
                        selected_item_id = self.choose_item(selected_block, week)
                        # Store attempts on the **selected** skill
                        list_att_per_skill[selected_block] += 1
                    selected_skill_indices = self.qmat[selected_item_id]

                    list_win_counters = []
                    list_attempt_counters = []
                    list_beta = []
                    list_h_features = []
                    for b in selected_skill_indices:
                        temp_sum_attempts += 1
                        list_win_counters.append(self.q[(b,"wins")].get_counters(week*7*24*3600))
                        list_attempt_counters.append(self.q[(b,"attempts")].get_counters(week*7*24*3600))
                        list_beta.append(self.skill_betas[b])
                        list_h_features.append((self.list_of_win_params[b],self.list_of_att_params[b]))
                        self.q[(b,"attempts")].push(week*7*24*3600)
                    outcome = gen_cplx_outcome(self.stud_alpha, self.item_deltas.flatten()[selected_item_id],
                                               list_beta, list_win_counters, list_attempt_counters, list_h_features)
                    if outcome > .5: # Deterministic output
                        for b in selected_skill_indices:
                            self.q[(b,"wins")].push(week*7*24*3600)
            res = self.get_performance_metric(week) # We compute the metrics *after* the reviewing phase
            temp_results.append(res[0])
            sum_attempts.append(temp_sum_attempts)
            temp_recall_probs.append(res[1])
            attempts_per_skill.append(list(list_att_per_skill))
        return temp_results, sum_attempts, temp_recall_probs, attempts_per_skill
    
    def get_performance_metric(self, t):
        """
        Return student performance metric (ACP) at a given t timestamp (WEEK).
        """
        temp_recall_probs = []
        for week in range(self.B):
            temp_recall_probs.append(gen_outcome(self.stud_alpha,self.item_deltas.mean(),self.skill_betas[week],
                                                 self.q[(week,"wins")].get_counters(t*7*3600*24),
                                                 self.q[(week,"attempts")].get_counters(t*7*3600*24),
                                                 self.list_of_win_params[week],
                                                 self.list_of_att_params[week]))
        return np.mean(temp_recall_probs), temp_recall_probs
