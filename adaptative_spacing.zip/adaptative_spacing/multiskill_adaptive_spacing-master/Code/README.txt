* launch_xp permet de lancer les simulations et de modifier des paramètres de la simulation

* experiment contient l'implémentation de l'expérience expliqué à la page 62 du document (page 82 lecteur PDF)

* student-simulator permet de simuler un étudiant, ses différents paramètres liés aux modèles DAS3H, les stratégies de selection

* strategies : implémente les stratégies greedy et multi_greedy que nous n'avons pas étudier dans le cadre de notre stage

*generation : permet la generation des paramètres du modèle et de la q-matrice

* utils : contient un certain nombre de fonctions utilisés par les autres classes. notemment le calcul de probabilité lié au model DAS3H